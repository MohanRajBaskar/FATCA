package com.dib.doc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocApplicationTests {

	@Test
	void contextLoads() {
	}

}
